import assert from "assert";
import { COLORS, Image, Color } from "../include/image.js";
import { flipColors, removeRed, imageMap, mapLine, mapToGB, mapFlipColors } from "./imageProcessing.js";

function takeAverage(x: number, y: number): number {
  return Math.floor((x + y) / 2);
}
describe("removeRed", () => {
  it("should remove red from the upper left corner", () => {
    const whiteImage = Image.create(10, 10, COLORS.WHITE);
    const gbImage = removeRed(whiteImage);
    const p = gbImage.getPixel(3, 2);

    assert(p[0] === 0, "The red channel should be 0.");
    assert(p[1] === 255, "The green channel should be 255.");
    assert(p[2] === 255, "The blue channel should be 255.");

    // or alternatively, using jest, if you'd like
    // https://jestjs.io/docs/expect#toequalvalue
    // Use expect with .toEqual to compare recursively all properties of object instances (also known as "deep" equality).

    expect(p).toEqual([0, 255, 255]);

    // This will produce output showing the exact differences between the two objects, which is really helpful
    // for debugging. However, again, please use the simpler assert syntax if this is too confusing.
    // Focus on making your tests well written and correct, rather than using one syntax or another.
  });

  it("should remove red from the center", () => {
    const whiteImage = Image.create(10, 10, COLORS.WHITE);
    const gbImage = removeRed(whiteImage);
    const p = gbImage.getPixel(9, 5);

    assert(p[0] === 0, "The red channel should be 0.");
    assert(p[1] === 255, "The green channel should be 255.");
    assert(p[2] === 255, "The blue channel should be 255.");
  });

  // More tests for removeRed go here.
  it("should remove red from a specific point", () => {
    const whiteImage = Image.create(10, 30, COLORS.WHITE);
    const gbImage = removeRed(whiteImage);
    const p = gbImage.getPixel(3, 6);

    assert(p[0] === 0, "The red channel should be 0.");
    assert(p[1] === 255, "The green channel should be 255.");
    assert(p[2] === 255, "The blue channel should be 255.");

    // or alternatively, using jest, if you'd like
    // https://jestjs.io/docs/expect#toequalvalue
    // Use expect with .toEqual to compare recursively all properties of object instances (also known as "deep" equality).

    expect(p).toEqual([0, 255, 255]);

    // This will produce output showing the exact differences between the two objects, which is really helpful
    // for debugging. However, again, please use the simpler assert syntax if this is too confusing.
    // Focus on making your tests well written and correct, rather than using one syntax or another.
  });
});

describe("flipColors", () => {
  it("should correctly flip top left corner", () => {
    const whiteImage = Image.create(10, 10, COLORS.WHITE);
    // A white image is not particularly helpful in this context
    whiteImage.setPixel(0, 0, [100, 0, 150]);
    const flippedWhiteImage = flipColors(whiteImage);
    const p = flippedWhiteImage.getPixel(0, 0);

    assert(p[0] === 75);
    assert(p[1] === 125);
    assert(p[2] === 50);
  });

  // More tests for flipColors go here.
  it("should correctly flip specific point", () => {
    const whiteImage = Image.create(10, 10, [50, 74, 30]);
    // A white image is not particularly helpful in this context
    whiteImage.setPixel(4, 3, [0, 30, 150]);
    const flippedWhiteImage = flipColors(whiteImage);
    const p = flippedWhiteImage.getPixel(4, 8);

    assert(p[0] === 52);
    assert(p[1] === 40);
    assert(p[2] === 62);
  });
});

describe("mapLine", () => {
  it("should change the image on a horizontal line via a function", () => {
    const whiteImage = Image.create(10, 10, [100, 40, 60]);
    // A white image is not particularly helpful in this context
    function flipTagetColors(c: Color): Color {
      const c1 = [...c];
      c1[0] = takeAverage(c[1], c[2]);
      c1[1] = takeAverage(c[2], c[0]);
      c1[2] = takeAverage(c[0], c[1]);
      return c1;
    }
    mapLine(whiteImage, 1, flipTagetColors);
    const p = whiteImage.getPixel(3, 2);

    assert(p[0] === 100);
    assert(p[1] === 40);
    assert(p[2] === 60);
  });
  it("should change the image on a horizontal line case 2 via a function", () => {
    const whiteImage = Image.create(10, 10, [60, 20, 30]);
    // A white image is not particularly helpful in this context
    function flipTagetColors(c: Color): Color {
      const c1 = [...c];
      c1[0] = takeAverage(c[1], c[2]);
      c1[1] = takeAverage(c[2], c[0]);
      c1[2] = takeAverage(c[0], c[1]);
      return c1;
    }
    mapLine(whiteImage, 2, flipTagetColors);
    const p = whiteImage.getPixel(3, 3);

    assert(p[0] === 60);
    assert(p[1] === 20);
    assert(p[2] === 30);
  });
  it("should change the image on a horizontal line case 3 via a function", () => {
    const whiteImage = Image.create(10, 10, [100, 40, 60]);
    // A white image is not particularly helpful in this context
    function flipTagetColors(c: Color): Color {
      const c1 = [...c];
      c1[0] = takeAverage(c[1], c[2]);
      c1[1] = takeAverage(c[2], c[0]);
      c1[2] = takeAverage(c[0], c[1]);
      return c1;
    }
    mapLine(whiteImage, 11, flipTagetColors);
    const p = whiteImage.getPixel(3, 2);

    assert(p[0] === 100);
    assert(p[1] === 40);
    assert(p[2] === 60);
  });
});

describe("imageMap", () => {
  it("should change the image via a function", () => {
    const whiteImage = Image.create(10, 10, [100, 2, 60]);
    // A white image is not particularly helpful in this context
    function flipTagetColors(c: Color): Color {
      const c1 = [...c];
      c1[0] = takeAverage(c[1], c[2]);
      c1[1] = takeAverage(c[2], c[0]);
      c1[2] = takeAverage(c[0], c[1]);
      return c1;
    }
    const flippedWhiteImage = imageMap(whiteImage, flipTagetColors);
    const p = flippedWhiteImage.getPixel(4, 0);

    assert(p[0] === 31);
    assert(p[1] === 80);
    assert(p[2] === 51);
  });
  it("should change the second image via a function", () => {
    const whiteImage = Image.create(10, 10, [20, 0, 5]);
    // A white image is not particularly helpful in this context
    function flipTagetColors(c: Color): Color {
      const c1 = [...c];
      c1[0] = takeAverage(c[1], c[2]);
      c1[1] = takeAverage(c[2], c[0]);
      c1[2] = takeAverage(c[0], c[1]);
      return c1;
    }
    const flippedWhiteImage = imageMap(whiteImage, flipTagetColors);
    const p = flippedWhiteImage.getPixel(4, 0);

    assert(p[0] === 2);
    assert(p[1] === 12);
    assert(p[2] === 10);
  });
});

describe("mapToGB", () => {
  it("should remove red from the upper left corner", () => {
    const whiteImage = Image.create(10, 10, COLORS.WHITE);
    const gbImage = mapToGB(whiteImage);
    const p = gbImage.getPixel(3, 9);

    assert(p[0] === 0, "The red channel should be 0.");
    assert(p[1] === 255, "The green channel should be 255.");
    assert(p[2] === 255, "The blue channel should be 255.");

    // or alternatively, using jest, if you'd like
    // https://jestjs.io/docs/expect#toequalvalue
    // Use expect with .toEqual to compare recursively all properties of object instances (also known as "deep" equality).

    expect(p).toEqual([0, 255, 255]);

    // This will produce output showing the exact differences between the two objects, which is really helpful
    // for debugging. However, again, please use the simpler assert syntax if this is too confusing.
    // Focus on making your tests well written and correct, rather than using one syntax or another.
  });
  it("should remove red from a position", () => {
    const whiteImage = Image.create(10, 10, COLORS.WHITE);
    const gbImage = mapToGB(whiteImage);
    const p = gbImage.getPixel(1, 9);

    assert(p[0] === 0, "The red channel should be 0.");
    assert(p[1] === 255, "The green channel should be 255.");
    assert(p[2] === 255, "The blue channel should be 255.");

    // or alternatively, using jest, if you'd like
    // https://jestjs.io/docs/expect#toequalvalue
    // Use expect with .toEqual to compare recursively all properties of object instances (also known as "deep" equality).

    expect(p).toEqual([0, 255, 255]);

    // This will produce output showing the exact differences between the two objects, which is really helpful
    // for debugging. However, again, please use the simpler assert syntax if this is too confusing.
    // Focus on making your tests well written and correct, rather than using one syntax or another.
  });
});

describe("mapFlipColors", () => {
  it("should correctly flip specific point", () => {
    const whiteImage = Image.create(10, 10, COLORS.WHITE);
    // A white image is not particularly helpful in this context
    whiteImage.setPixel(4, 0, [10, 0, 150]);
    const flippedWhiteImage = mapFlipColors(whiteImage);
    const p = flippedWhiteImage.getPixel(4, 0);

    assert(p[0] === 75);
    assert(p[1] === 80);
    assert(p[2] === 5);
  });
  it("should correctly flip top left corner", () => {
    const whiteImage = Image.create(10, 10, COLORS.WHITE);
    // A white image is not particularly helpful in this context
    whiteImage.setPixel(0, 0, [100, 0, 150]);
    const flippedWhiteImage = mapFlipColors(whiteImage);
    const p = flippedWhiteImage.getPixel(0, 0);

    assert(p[0] === 75);
    assert(p[1] === 125);
    assert(p[2] === 50);
  });
});
