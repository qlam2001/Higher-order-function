/**
 * Removes all red color from an image
 * @param img An image
 * @returns A new image where each pixel has the red channel removed
 */
export function removeRed(img) {
    const resultImg = img.copy();
    for (let i = 0; i < img.width; ++i) {
        for (let j = 0; j < img.height; ++j) {
            const arrSol = img.getPixel(i, j);
            arrSol[0] = 0;
            resultImg.setPixel(i, j, arrSol);
        }
    }
    return resultImg;
}
/**
 * Flips the colors of an image
 * @param img An image
 * @returns A new image where each pixel's channel has been
 *  set as the truncated average of the other two
 */
function takeAverage(x, y) {
    return Math.floor((x + y) / 2);
}
export function flipColors(img) {
    const resultImg = img.copy();
    for (let i = 0; i < img.width; ++i) {
        for (let j = 0; j < img.height; ++j) {
            const colorChannel = img.getPixel(i, j);
            const colorChannelResult = [...colorChannel];
            colorChannelResult[0] = takeAverage(colorChannel[1], colorChannel[2]);
            colorChannelResult[1] = takeAverage(colorChannel[0], colorChannel[2]);
            colorChannelResult[2] = takeAverage(colorChannel[0], colorChannel[1]);
            resultImg.setPixel(i, j, colorChannelResult);
        }
    }
    return resultImg;
}
/**
 * Modifies the given `img` such that the value of each pixel
 * in the given line is the result of applying `func` to the
 * corresponding pixel of `img`. If `lineNo` is not a valid line
 * number, then `img` should not be modified.
 * @param img An image
 * @param lineNo A line number
 * @param func A color transformation function
 */
export function mapLine(img, lineNo, func) {
    if (lineNo >= 0 && lineNo < img.height && Number.isInteger(lineNo)) {
        for (let i = 0; i < img.width; ++i) {
            img.setPixel(i, lineNo, func(img.getPixel(i, lineNo)));
        }
    }
}
/**
 * The result must be a new image with the same dimensions as `img`.
 * The value of each pixel in the new image should be the result of
 * applying `func` to the corresponding pixel of `img`.
 * @param img An image
 * @param func A color transformation function
 */
export function imageMap(img, func) {
    const resultImage = img.copy();
    for (let i = 0; i < img.height; i++) {
        mapLine(resultImage, i, func);
    }
    return resultImage;
}
/**
 * Removes all red color from an image
 * @param img An image
 * @returns A new image where each pixel has the red channel removed
 */
export function mapToGB(img) {
    function removeAllRed(c) {
        c[0] = 0;
        return c;
    }
    return imageMap(img, removeAllRed);
}
/**
 * Flips the colors of an image
 * @param img An image
 * @returns A new image where each pixels channel has been
 *  set as the truncated average of the other two
 */
export function mapFlipColors(img) {
    function flipTagetColors(c) {
        const c1 = [...c];
        c1[0] = takeAverage(c[1], c[2]);
        c1[1] = takeAverage(c[2], c[0]);
        c1[2] = takeAverage(c[0], c[1]);
        return c1;
    }
    return imageMap(img, flipTagetColors);
}
//# sourceMappingURL=imageProcessing.js.map